using System;
using System.Drawing;
using System.Windows.Forms;
using SharpGL;
using SharpGL.Enumerations;

namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        private OpenGL gl;
        private Random random = new Random();

        private float[,] heightMap;
        private int mapSize = 20; 
        private float roughness = 0.9f;
        private float scale = 20.0f;

        private float cameraDistance = -50.0f; 
        private float rotationX = 0.0f; 
        private float rotationY = 0.0f; 
        private bool isRightMouseButtonDown = false; 
        private Point lastMousePosition; 


        public Form1()
        {
            InitializeComponent();
            if (openGLControl == null)
            {
                openGLControl = new OpenGLControl();
                this.Controls.Add(openGLControl);
                openGLControl.Dock = DockStyle.Fill;
            }
            openGLControl.OpenGL.ClearColor(1.0f, 1.0f, 1.0f, 1.0f);
            GenerateHeightMap();

            openGLControl.OpenGLDraw += openGLControl_OpenGLDraw;
            openGLControl.OpenGLInitialized += openGLControl_OpenGLInitialized;
            openGLControl.Resized += openGLControl_Resized;

            openGLControl.MouseWheel += openGLControl_MouseWheel;
            openGLControl.MouseDown += openGLControl_MouseDown;
            openGLControl.MouseUp += openGLControl_MouseUp;
            openGLControl.MouseMove += openGLControl_MouseMove;

            trackBarRoughness.ValueChanged += trackBarRoughness_ValueChanged;
            trackBarScale.ValueChanged += trackBarScale_ValueChanged;
        }

        private void openGLControl_OpenGLInitialized(object sender, EventArgs e)
        {
            gl = openGLControl.OpenGL;

            gl.ClearColor(0.0f, 0.0f, 1.0f, 1.0f);

            gl.Enable(OpenGL.GL_DEPTH_TEST);
            gl.Enable(OpenGL.GL_LIGHTING);
            gl.Enable(OpenGL.GL_LIGHT0);
            gl.Enable(OpenGL.GL_COLOR_MATERIAL);
            gl.Enable(OpenGL.GL_NORMALIZE);

            float[] lightPosition = { 1.0f, 1.0f, 1.0f, 0.0f };
            gl.Light(OpenGL.GL_LIGHT0, OpenGL.GL_POSITION, lightPosition);
        }
        private void openGLControl_Resized(object sender, EventArgs e)
        {
            gl = openGLControl.OpenGL;

            gl.MatrixMode(OpenGL.GL_PROJECTION);
            gl.LoadIdentity();

            gl.Perspective(45.0f, (float)openGLControl.Width / (float)openGLControl.Height, 0.1f, 1000.0f);

            gl.MatrixMode(OpenGL.GL_MODELVIEW);
        }
        private void openGLControl_OpenGLDraw(object sender, RenderEventArgs args)
        {
            gl = openGLControl.OpenGL;
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
            gl.LoadIdentity();

            gl.Translate(0.0f, 0.0f, cameraDistance);
            gl.Rotate(rotationX, 1.0f, 0.0f, 0.0f); 
            gl.Rotate(rotationY, 0.0f, 1.0f, 0.0f);

            for (int x = 0; x < mapSize - 1; x++)
            {
                for (int y = 0; y < mapSize - 1; y++)
                {
                    DrawQuad(gl, x, y); 
                }
            }

            DrawWireframe(gl);

            gl.Flush();
            openGLControl.Invalidate();
        }
        private void DrawWireframe(OpenGL gl)
        {
            gl.Color(0.0f, 0.0f, 0.0f); 

            gl.Begin(OpenGL.GL_LINES);

            for (int x = 0; x < mapSize - 1; x++)
            {
                for (int y = 0; y < mapSize - 1; y++)
                {
                    gl.Vertex(x, heightMap[x, y] * scale, y);
                    gl.Vertex(x + 1, heightMap[x + 1, y] * scale, y);

                    gl.Vertex(x + 1, heightMap[x + 1, y] * scale, y);
                    gl.Vertex(x, heightMap[x, y + 1] * scale, y + 1);

                    gl.Vertex(x, heightMap[x, y + 1] * scale, y + 1);
                    gl.Vertex(x + 1, heightMap[x + 1, y + 1] * scale, y + 1);

                    gl.Vertex(x + 1, heightMap[x + 1, y] * scale, y);
                    gl.Vertex(x + 1, heightMap[x + 1, y + 1] * scale, y + 1);

                    gl.Vertex(x + 1, heightMap[x + 1, y + 1] * scale, y + 1);
                    gl.Vertex(x, heightMap[x, y + 1] * scale, y + 1);
                }
            }

            gl.End();
        }

        private void openGLControl_MouseWheel(object sender, MouseEventArgs e)
        {
            if (e.Delta > 0)
                cameraDistance += 1.0f; 
            else
                cameraDistance -= 1.0f; 

            openGLControl.Invalidate(); 
        }
        private void openGLControl_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                isRightMouseButtonDown = true;
                lastMousePosition = e.Location; // ��������� ��������� ������� ����
            }
        }
        private void openGLControl_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                isRightMouseButtonDown = false;
            }
        }
        private void openGLControl_MouseMove(object sender, MouseEventArgs e)
        {
            if (isRightMouseButtonDown)
            {
                // ��������� ������� � �������� ����
                int deltaX = e.X - lastMousePosition.X;
                int deltaY = e.Y - lastMousePosition.Y;

                // ��������� ���� ��������
                rotationX += deltaY * 0.2f; // �������� �� ��� X
                rotationY += deltaX * 0.2f; // �������� �� ��� Y

                lastMousePosition = e.Location; // ��������� ��������� ������� ����
                openGLControl.Invalidate(); // �������������� �����
            }
        }

        private void GenerateHeightMap()
        {
            heightMap = new float[mapSize, mapSize];

            heightMap[0, 0] = RandomHeight();
            heightMap[0, mapSize - 1] = RandomHeight();
            heightMap[mapSize - 1, 0] = RandomHeight();
            heightMap[mapSize - 1, mapSize - 1] = RandomHeight();

            int step = mapSize - 1;

            while (step > 1)
            {
                int halfStep = step / 2;

                for (int x = halfStep; x < mapSize - 1; x += step)
                {
                    for (int y = halfStep; y < mapSize - 1; y += step)
                        DiamondStep(x, y, halfStep);
                }

                for (int x = 0; x < mapSize; x += halfStep)
                {
                    for (int y = (x + halfStep) % step; y < mapSize; y += step)
                        SquareStep(x, y, halfStep);
                }

                step /= 2;
                roughness *= 0.3f;
            }
        }
        private void DiamondStep(int x, int y, int size)
        {
            float avg = 0;
            int count = 0;

            if (x - size >= 0 && y - size >= 0) { avg += heightMap[x - size, y - size]; count++; }
            if (x - size >= 0 && y + size < mapSize) { avg += heightMap[x - size, y + size]; count++; }
            if (x + size < mapSize && y - size >= 0) { avg += heightMap[x + size, y - size]; count++; }
            if (x + size < mapSize && y + size < mapSize) { avg += heightMap[x + size, y + size]; count++; }

            if (count > 0)
                heightMap[x, y] = avg / count + RandomHeight() * roughness;
        }
        private void SquareStep(int x, int y, int size)
        {
            float avg = 0;
            int count = 0;

            if (x - size >= 0) { avg += heightMap[x - size, y]; count++; }
            if (x + size < mapSize) { avg += heightMap[x + size, y]; count++; }
            if (y - size >= 0) { avg += heightMap[x, y - size]; count++; }
            if (y + size < mapSize) { avg += heightMap[x, y + size]; count++; }

            heightMap[x, y] = avg / count + RandomHeight() * roughness;
        }
        private float RandomHeight()
        {
            return (float)(random.NextDouble() * 2 - 1);
        }
        private void DrawQuad(OpenGL gl, int x, int y)
        {
            gl.Begin(OpenGL.GL_TRIANGLES);

            float height1 = heightMap[x, y] * scale;
            float height2 = heightMap[x + 1, y] * scale;
            float height3 = heightMap[x + 1, y + 1] * scale;
            float height4 = heightMap[x, y + 1] * scale;

            float color1 = GetColorFactor(height1);
            gl.Color(color1, 0.0f, 1.0f - color1);
            gl.Vertex(x, height1, y);

            float color2 = GetColorFactor(height2);
            gl.Color(color2, 0.0f, 1.0f - color2);
            gl.Vertex(x + 1, height2, y);

            float color3 = GetColorFactor(height4);
            gl.Color(color3, 0.0f, 1.0f - color3);
            gl.Vertex(x, height4, y + 1);

            float color4 = GetColorFactor(height2);
            gl.Color(color4, 0.0f, 1.0f - color4);
            gl.Vertex(x + 1, height2, y);

            float color5 = GetColorFactor(height3);
            gl.Color(color5, 0.0f, 1.0f - color5);
            gl.Vertex(x + 1, height3, y + 1);

            float color6 = GetColorFactor(height4);
            gl.Color(color6, 0.0f, 1.0f - color6);
            gl.Vertex(x, height4, y + 1);

            gl.End();
        }
        private float GetColorFactor(float height)
        {
            return Math.Max(0.0f, Math.Min(1.0f, (height / scale + 0.5f)));  
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            roughness = (trackBarRoughness.Value / 100.0f) * 0.5f;
            scale = trackBarScale.Value;  

            GenerateHeightMap();

            openGLControl.Invalidate();
        }
        private void trackBarRoughness_ValueChanged(object sender, EventArgs e)
        {
            roughness = trackBarRoughness.Value / 100.0f;
        }
        private void trackBarScale_ValueChanged(object sender, EventArgs e)
        {
            scale = trackBarScale.Value;
        }

    }
}