﻿namespace WinFormsApp2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            openGLControl = new SharpGL.OpenGLControl();
            btnGenerate = new Button();
            trackBarRoughness = new TrackBar();
            trackBarScale = new TrackBar();
            label1 = new Label();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)openGLControl).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBarRoughness).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBarScale).BeginInit();
            SuspendLayout();
            // 
            // openGLControl
            // 
            openGLControl.BackColor = SystemColors.ControlLightLight;
            openGLControl.Dock = DockStyle.Fill;
            openGLControl.DrawFPS = false;
            openGLControl.Location = new Point(0, 0);
            openGLControl.Margin = new Padding(4, 3, 4, 3);
            openGLControl.Name = "openGLControl";
            openGLControl.OpenGLVersion = SharpGL.Version.OpenGLVersion.OpenGL2_1;
            openGLControl.RenderContextType = SharpGL.RenderContextType.DIBSection;
            openGLControl.RenderTrigger = SharpGL.RenderTrigger.TimerBased;
            openGLControl.Size = new Size(800, 450);
            openGLControl.TabIndex = 0;
            // 
            // btnGenerate
            // 
            btnGenerate.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnGenerate.Location = new Point(668, 140);
            btnGenerate.Name = "btnGenerate";
            btnGenerate.Size = new Size(106, 23);
            btnGenerate.TabIndex = 1;
            btnGenerate.Text = "Сгенерировать";
            btnGenerate.UseVisualStyleBackColor = true;
            btnGenerate.Click += btnGenerate_Click;
            // 
            // trackBarRoughness
            // 
            trackBarRoughness.Location = new Point(668, 12);
            trackBarRoughness.Maximum = 100;
            trackBarRoughness.Minimum = 1;
            trackBarRoughness.Name = "trackBarRoughness";
            trackBarRoughness.Size = new Size(104, 45);
            trackBarRoughness.TabIndex = 2;
            trackBarRoughness.Value = 50;
            // 
            // trackBarScale
            // 
            trackBarScale.Location = new Point(668, 73);
            trackBarScale.Maximum = 50;
            trackBarScale.Name = "trackBarScale";
            trackBarScale.Size = new Size(104, 45);
            trackBarScale.TabIndex = 3;
            trackBarScale.Value = 25;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(600, 12);
            label1.Name = "label1";
            label1.Size = new Size(62, 15);
            label1.TabIndex = 4;
            label1.Text = "Гладкость";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(612, 73);
            label2.Name = "label2";
            label2.Size = new Size(53, 15);
            label2.TabIndex = 5;
            label2.Text = "Высоты:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(trackBarScale);
            Controls.Add(trackBarRoughness);
            Controls.Add(btnGenerate);
            Controls.Add(openGLControl);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)openGLControl).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBarRoughness).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBarScale).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private SharpGL.OpenGLControl openGLControl;
        private Button btnGenerate;
        private TrackBar trackBarRoughness;
        private TrackBar trackBarScale;
        private Label label1;
        private Label label2;
    }
}
