using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private Random random;

        public Form1()
        {
            InitializeComponent();

            random = new Random();
            Text = "����������� ������";
            Size = new Size(1000, 800);
            DoubleBuffered = true;
            Paint += Form1_Paint;
        }

        private void RegenerateButton_Click(object sender, EventArgs e)
        {
            Invalidate();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.FromArgb(240, 248, 255));

            int startX = ClientSize.Width / 2;
            int startY = ClientSize.Height - 100;
            double startAngle = -90;
            int depth = (int)numericUpDown1.Value;
            int length = 120;

            DrawFractalTree(g, startX, startY, startAngle, length, depth, depth);
        }

        private void DrawFractalTree(Graphics g, int x, int y, double angle, int length, int depth, int maxDepth)
        {
            if (depth == 0 || length < 3) return;

            int endX = x + (int)(Math.Cos(angle * Math.PI / 180) * length);
            int endY = y + (int)(Math.Sin(angle * Math.PI / 180) * length);

            Color branchColor = GetBranchColor(depth, maxDepth);
            using (Pen pen = new Pen(branchColor, Math.Max(1, depth * 0.7f)))
            {
                g.DrawLine(pen, x, y, endX, endY);
            }

            double angleOffset = random.NextDouble() * 10 - 5;

            double leftBranchAngle = angle - 30 + angleOffset;
            double rightBranchAngle = angle + 30 + angleOffset;

            int leftBranchLength = (int)(length * (0.7 + random.NextDouble() * 0.2));
            int rightBranchLength = (int)(length * (0.7 + random.NextDouble() * 0.2));

            double[] angleVariations = new double[]
            {
                random.NextDouble() * 15 - 7.5,
                random.NextDouble() * 15 - 7.5
            };

            DrawFractalTree(g, endX, endY, leftBranchAngle + angleVariations[0], leftBranchLength, depth - 1, maxDepth);
            DrawFractalTree(g, endX, endY, rightBranchAngle + angleVariations[1], rightBranchLength, depth - 1, maxDepth);

            if (random.NextDouble() > 0.5)
            {
                int extraBranchLength = (int)(length * (0.4 + random.NextDouble() * 0.2));
                double extraBranchAngle = angle + random.NextDouble() * 40 - 20;
                DrawFractalTree(g, endX, endY, extraBranchAngle, extraBranchLength, depth - 2, maxDepth);
            }
        }

        private Color GetBranchColor(int depth, int maxDepth)
        {
            int startR = 101, startG = 67, startB = 33;
            int endR = 144, endG = 238, endB = 144;

            depth = Math.Max(0, Math.Min(depth, maxDepth));

            double t = (double)(maxDepth - depth) / maxDepth;

            int r = (int)(startR + t * (endR - startR));
            int g = (int)(startG + t * (endG - startG));
            int b = (int)(startB + t * (endB - startB));

            return Color.FromArgb(r, g, b);
        }
    }
}
